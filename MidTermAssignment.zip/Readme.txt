MidTermAssignment Computer Career and Programming IT 3 
Epafroditus George Clement Djaja in each folder there is the source code, solution,csproject and the executable application for each number 
Thank You for your Attention.